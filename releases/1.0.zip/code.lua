-- This file is loaded from "Hide Blizzard Voice Activity.toc"

-- This is a comment, you can replace it with the lua code that you wish to make into an Addon!
VoiceActivityManager:Hide()
